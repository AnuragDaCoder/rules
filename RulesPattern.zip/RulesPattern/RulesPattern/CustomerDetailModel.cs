﻿namespace RulesPattern
{
    public class CustomerDetailModel
    {
        public int Id { get; set; }
        public bool IsCustomerWorthiness { get; set; }
        public bool IsCustomerLoyal { get; set; }
        public bool IsCustomerSpecial { get; set; }
        public bool IsCustomerValid { get; set; }
    }
}
