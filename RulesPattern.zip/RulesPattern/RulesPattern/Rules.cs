﻿namespace RulesPattern
{
    public interface IRule
    {
        bool Matches(CustomerDetailModel input);
        void Apply(CustomerDetailModel input);
    }

    public class RulesEvaluator
    {
        private IEnumerable<IRule> _rules;

        public RulesEvaluator(IEnumerable<IRule> rules)
        {
            _rules =rules;
        }
        public void Execute(CustomerDetailModel customerDetailModel)
        {
            foreach (var rule in _rules)
            {
                if (rule.Matches(customerDetailModel))
                {
                    rule.Apply(customerDetailModel);
                }
            }
        }
    }

    public class CustomerWorthiNessRule : IRule
    {
        public void Apply(CustomerDetailModel input)
        {
            input.IsCustomerWorthiness = true;
        }

        public bool Matches(CustomerDetailModel input)
        {
            //some condition check here ...true or false..
            return true;
        }
    }


    public class CustomerLoyalRule : IRule
    {
        public void Apply(CustomerDetailModel input)
        {
            input.IsCustomerLoyal = true;
        }

        public bool Matches(CustomerDetailModel input)
        {
            //some condition check here ...true or false..
            return true;
        }
    }

    public class CustomerSpecialRule : IRule
    {
        public void Apply(CustomerDetailModel input)
        {
            //some condition check then return true or false..
            input.IsCustomerSpecial = false;
        }

        public bool Matches(CustomerDetailModel input)
        {
            //some condition check here ...true or false..
            return true;
        }
    }

    public class CustomerValid : IRule
    {
        public void Apply(CustomerDetailModel input)
        {
            input.IsCustomerValid = true;
        }

        public bool Matches(CustomerDetailModel input)
        {
            //some condition check here ...true or false..
            return true;
        }
    }
}
