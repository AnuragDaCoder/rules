﻿using RulesPattern;

var custDetailModel = new CustomerDetailModel();
var rules = new List<IRule>()
{
    new CustomerWorthiNessRule(),
    new CustomerLoyalRule(),
    new CustomerSpecialRule(),
    new CustomerValid()
};

new RulesEvaluator(rules).Execute(custDetailModel);
Console.WriteLine($"Is Customer Credit Valid ? {custDetailModel.IsCustomerValid}");
Console.WriteLine($"Is Customer Credit Worthy ? {custDetailModel.IsCustomerWorthiness}");
Console.WriteLine($"Is Customer Credit Special ? {custDetailModel.IsCustomerSpecial}");
Console.WriteLine($"Is Customer Credit Loyal ? {custDetailModel.IsCustomerLoyal}");

